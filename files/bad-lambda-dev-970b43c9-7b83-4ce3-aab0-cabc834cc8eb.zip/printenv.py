import json
import subprocess

def lambda_handler(event, context):
    output = subprocess.run("printenv", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
    return {
        "statusCode": 200,
        "body": output.stdout
        #"body": json.dumps(output.stdout)
    }
